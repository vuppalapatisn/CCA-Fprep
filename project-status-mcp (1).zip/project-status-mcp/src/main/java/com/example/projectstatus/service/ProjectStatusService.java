package com.example.projectstatus.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.time.Clock;
import java.util.ArrayList;
import java.util.List;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.example.projectstatus.model.ProjectStatus;
import com.example.projectstatus.model.ProjectStatus.Tasks;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Business logic lives here; the MCP classes are thin adapters.
 * Read-only: loads a fixed classpath file. No user-supplied paths, no commands, no network.
 */
@Service
public class ProjectStatusService {

    /** Bump when the response shape changes. */
    public static final int SCHEMA_VERSION = 1;

    private static final String DATA_FILE = "project-status.json";
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private final Clock clock;

    public ProjectStatusService(Clock clock) {
        this.clock = clock;
    }

    public ProjectStatus currentStatus() {
        ProjectStatus raw = load();
        Tasks t = raw.tasks();
        if (t == null) {
            throw new IllegalStateException("'tasks' is missing in " + DATA_FILE);
        }
        Tasks tasks = new Tasks(t.total(), t.done(), t.inProgress(),
                Math.max(0, t.total() - t.done() - t.inProgress()));
        List<ProjectStatus.Blocker> blockers = raw.blockers() == null ? List.of() : raw.blockers();

        return new ProjectStatus(
                SCHEMA_VERSION,
                raw.project(),
                raw.status(),
                raw.summary(),
                tasks,
                raw.metrics(),
                blockers,
                raw.nextStep(),
                clock.instant().toString());
    }

    /** Same snapshot as pretty JSON text, used as the {status} input of the prompt template. */
    public String currentStatusJson() {
        try {
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(currentStatus());
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Could not serialize project status", e);
        }
    }

    /** "JSON shape" check: required fields present. An empty list means the shape is valid. */
    public static List<String> problems(ProjectStatus s) {
        List<String> p = new ArrayList<>();
        if (s.version() != SCHEMA_VERSION) p.add("version must be " + SCHEMA_VERSION);
        if (!StringUtils.hasText(s.project())) p.add("project is missing");
        if (!StringUtils.hasText(s.status())) p.add("status is missing");
        if (!StringUtils.hasText(s.summary())) p.add("summary is missing");
        if (!StringUtils.hasText(s.nextStep())) p.add("next_step is missing");
        if (!StringUtils.hasText(s.timestamp())) p.add("timestamp is missing");
        if (s.tasks() == null) p.add("tasks is missing");
        if (s.metrics() == null) p.add("metrics is missing");
        if (s.blockers() == null) p.add("blockers is missing");
        return p;
    }

    private ProjectStatus load() {
        try (InputStream in = new ClassPathResource(DATA_FILE).getInputStream()) {
            return MAPPER.readValue(in, ProjectStatus.class);
        } catch (IOException e) {
            throw new UncheckedIOException("Could not read " + DATA_FILE, e);
        }
    }
}
