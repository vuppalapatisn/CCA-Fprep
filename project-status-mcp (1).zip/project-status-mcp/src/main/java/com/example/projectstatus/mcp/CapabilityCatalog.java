package com.example.projectstatus.mcp;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springaicommunity.mcp.annotation.McpPrompt;
import org.springaicommunity.mcp.annotation.McpResource;
import org.springaicommunity.mcp.annotation.McpTool;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.stereotype.Component;
import org.springframework.util.ClassUtils;

/**
 * Discovers what this server registers, straight from the annotations.
 * Used by the startup self-check and by the tests, so both see the same "capability map".
 */
public final class CapabilityCatalog {

    public static final String BASE_PACKAGE = "com.example.projectstatus";

    public record Registered(List<String> tools, List<String> resources, List<String> prompts) {
    }

    private CapabilityCatalog() {
    }

    public static Registered scan() {
        return scan(BASE_PACKAGE);
    }

    public static Registered scan(String basePackage) {
        List<String> tools = new ArrayList<>();
        List<String> resources = new ArrayList<>();
        List<String> prompts = new ArrayList<>();

        var scanner = new ClassPathScanningCandidateComponentProvider(false);
        scanner.addIncludeFilter(new AnnotationTypeFilter(Component.class));

        for (BeanDefinition bd : scanner.findCandidateComponents(basePackage)) {
            Class<?> type = load(bd.getBeanClassName());
            for (Method m : type.getDeclaredMethods()) {
                McpTool tool = m.getAnnotation(McpTool.class);
                if (tool != null) tools.add(tool.name());
                McpResource resource = m.getAnnotation(McpResource.class);
                if (resource != null) resources.add(resource.uri());
                McpPrompt prompt = m.getAnnotation(McpPrompt.class);
                if (prompt != null) prompts.add(prompt.name());
            }
        }
        Collections.sort(tools);
        Collections.sort(resources);
        Collections.sort(prompts);
        return new Registered(List.copyOf(tools), List.copyOf(resources), List.copyOf(prompts));
    }

    private static Class<?> load(String className) {
        try {
            return ClassUtils.forName(className, ClassUtils.getDefaultClassLoader());
        } catch (ClassNotFoundException | LinkageError e) {
            throw new IllegalStateException("Cannot load " + className, e);
        }
    }
}
