package com.example.projectstatus;

import java.time.Clock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class ProjectStatusMcpApplication {

    private static final Logger log = LoggerFactory.getLogger(ProjectStatusMcpApplication.class);

    public static void main(String[] args) {
        try {
            SpringApplication.run(ProjectStatusMcpApplication.class, args);
        } catch (RuntimeException ex) {
            // Fail fast and be noisy: a stdio server that half-starts just looks "hung" to the host.
            log.error("Startup failed: {}", ex.getMessage(), ex);
            System.exit(1);
        }
    }

    @Bean
    Clock clock() {
        return Clock.systemUTC();
    }
}
