package com.example.projectstatus.mcp;

import static io.modelcontextprotocol.spec.McpSchema.ReadResourceResult;
import static io.modelcontextprotocol.spec.McpSchema.TextResourceContents;

import java.util.List;

import org.springaicommunity.mcp.annotation.McpResource;
import org.springframework.stereotype.Component;

import com.example.projectstatus.Capabilities;
import com.example.projectstatus.service.DocumentService;

/**
 * Resource = READ. Identified and read by a clear URI. Context, not execution:
 * readable, not actionable.
 *
 * The URI is a logical name mapped to ONE bundled file. It is never turned into a
 * file-system path, so a client cannot use it to read anything else.
 *
 * Listing fields: type text/markdown, a description, and read-only. MCP has no standard
 * "tags" field, so the tags (docs, onboarding, public) are carried in the description text.
 */
@Component
public class ReadmeResource {

    private final DocumentService documents;

    public ReadmeResource(DocumentService documents) {
        this.documents = documents;
    }

    @McpResource(
            uri = Capabilities.RESOURCE_README_URI,
            name = "README",
            description = "Project overview, setup, and usage. Read-only. Tags: docs, onboarding, public.",
            mimeType = "text/markdown")
    public ReadResourceResult readme() {
        return new ReadResourceResult(List.of(new TextResourceContents(
                Capabilities.RESOURCE_README_URI, "text/markdown", documents.readme())));
    }
}
