package com.example.projectstatus.startup;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.example.projectstatus.Capabilities;
import com.example.projectstatus.mcp.CapabilityCatalog;
import com.example.projectstatus.mcp.CapabilityCatalog.Registered;
import com.example.projectstatus.service.DocumentService;
import com.example.projectstatus.service.ProjectStatusService;

/**
 * "Add startup logs. Fail fast. Be noisy. Make problems obvious."
 *
 * Runs at startup and logs to stderr (see logback-spring.xml). Covers the "check the basics" list:
 *   - registration names match exactly (tool / resource / prompt)
 *   - the README loads
 *   - the status data has the expected JSON shape
 * If anything is wrong the app refuses to start, so a broken server never looks "up but silent".
 */
@Component
public class StartupSelfCheck implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(StartupSelfCheck.class);

    private final ProjectStatusService statusService;
    private final DocumentService documents;

    public StartupSelfCheck(ProjectStatusService statusService, DocumentService documents) {
        this.statusService = statusService;
        this.documents = documents;
    }

    @Override
    public void run(ApplicationArguments args) {
        log.info("Starting MCP server '{}' v{} over stdio (java {}, cwd {})",
                Capabilities.SERVER_NAME, Capabilities.SERVER_VERSION,
                System.getProperty("java.version"), System.getProperty("user.dir"));
        verify(CapabilityCatalog.scan());
        log.info("Ready. Waiting for JSON-RPC messages on stdin.");
    }

    public void verify(Registered registered) {
        List<String> problems = new ArrayList<>();

        expect(problems, "tools", registered.tools(), List.of(Capabilities.TOOL_GET_PROJECT_STATUS));
        expect(problems, "resources", registered.resources(), List.of(Capabilities.RESOURCE_README_URI));
        expect(problems, "prompts", registered.prompts(), List.of(Capabilities.PROMPT_SUMMARIZE_PROJECT));

        try {
            if (!StringUtils.hasText(documents.readme())) {
                problems.add("README is empty");
            }
        } catch (RuntimeException e) {
            problems.add("README cannot be read: " + e.getMessage());
        }

        try {
            problems.addAll(ProjectStatusService.problems(statusService.currentStatus()));
        } catch (RuntimeException e) {
            problems.add("Status data cannot be read: " + e.getMessage());
        }

        if (!problems.isEmpty()) {
            problems.forEach(p -> log.error("Self-check failed: {}", p));
            throw new IllegalStateException("Startup self-check failed: " + problems);
        }
        log.info("Self-check passed. tools={}, resources={}, prompts={}",
                registered.tools(), registered.resources(), registered.prompts());
    }

    private static void expect(List<String> problems, String kind, List<String> actual, List<String> expected) {
        if (!actual.equals(expected)) {
            problems.add("Registered " + kind + " " + actual + " but expected " + expected);
        }
    }
}
