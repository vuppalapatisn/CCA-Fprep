package com.example.projectstatus.mcp;

import static io.modelcontextprotocol.spec.McpSchema.GetPromptResult;
import static io.modelcontextprotocol.spec.McpSchema.PromptMessage;
import static io.modelcontextprotocol.spec.McpSchema.Role;
import static io.modelcontextprotocol.spec.McpSchema.TextContent;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.springaicommunity.mcp.annotation.McpArg;
import org.springaicommunity.mcp.annotation.McpPrompt;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.example.projectstatus.Capabilities;
import com.example.projectstatus.service.DocumentService;
import com.example.projectstatus.service.ProjectStatusService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Prompt = a named, reviewable, reusable workflow ("Don't hide prompts in code").
 *
 * One prompt, many callers: the template is fixed and versioned, and only the inputs change.
 *
 * Arguments (all optional):
 *   readme   README text, or the URI of a REGISTERED resource (default: file:///README.md).
 *            Any other URI is rejected: unregistered = not available.
 *   status   Project status JSON. Default: the server's own get_project_status snapshot.
 *   version  Prompt version, "1" or "2" (default: latest).
 */
@Component
public class SummarizeProjectPrompt {

    static final int MAX_INPUT_CHARS = 20_000;

    private static final Pattern URI_LIKE = Pattern.compile("^[A-Za-z][A-Za-z0-9+.-]*://\\S*$");
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private final DocumentService documents;
    private final ProjectStatusService statusService;

    public SummarizeProjectPrompt(DocumentService documents, ProjectStatusService statusService) {
        this.documents = documents;
        this.statusService = statusService;
    }

    @McpPrompt(
            name = Capabilities.PROMPT_SUMMARIZE_PROJECT,
            description = "Summarize the project for a user. Inputs: readme, status. "
                    + "Output: health, key metrics, risks and the next best action. "
                    + "Versioned: use 'version' to pin an older template.")
    public GetPromptResult summarizeProject(
            @McpArg(name = "readme", description = "README text, or the URI of a registered resource "
                    + "(default file:///README.md)", required = false) String readme,
            @McpArg(name = "status", description = "Project status JSON "
                    + "(default: current get_project_status result)", required = false) String status,
            @McpArg(name = "version", description = "Prompt version: 1 or 2 (default 2)",
                    required = false) String version) {

        String v = StringUtils.hasText(version) ? version.trim() : PromptTemplates.LATEST;
        String template = PromptTemplates.template(v); // fails fast on unknown versions

        Map<String, String> inputs = new HashMap<>();
        inputs.put("readme", resolveReadme(readme));
        if ("1".equals(v)) {
            inputs.put("changelog", documents.changelog());
        } else {
            inputs.put("status", resolveStatus(status));
        }

        String text = PromptTemplates.render(template, inputs);
        return new GetPromptResult(
                Capabilities.PROMPT_SUMMARIZE_PROJECT + " v" + v,
                List.of(new PromptMessage(Role.USER, new TextContent(text))));
    }

    private String resolveReadme(String arg) {
        if (!StringUtils.hasText(arg)) {
            return documents.readme();
        }
        String value = arg.trim();
        if (URI_LIKE.matcher(value).matches()) {
            if (Capabilities.RESOURCE_README_URI.equals(value)) {
                return documents.readme();
            }
            throw new IllegalArgumentException("Unknown resource URI '" + value
                    + "'. Only registered resources can be read: " + Capabilities.RESOURCE_README_URI);
        }
        requireSize("readme", value);
        return value;
    }

    private String resolveStatus(String arg) {
        if (!StringUtils.hasText(arg)) {
            return statusService.currentStatusJson();
        }
        requireSize("status", arg);
        try {
            JsonNode node = MAPPER.readTree(arg);
            if (node == null || !node.isObject()) {
                throw new IllegalArgumentException("status must be a JSON object");
            }
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(node);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("status is not valid JSON: " + e.getOriginalMessage());
        }
    }

    private static void requireSize(String name, String value) {
        if (value.length() > MAX_INPUT_CHARS) {
            throw new IllegalArgumentException(name + " is too large (max " + MAX_INPUT_CHARS + " characters)");
        }
    }
}
