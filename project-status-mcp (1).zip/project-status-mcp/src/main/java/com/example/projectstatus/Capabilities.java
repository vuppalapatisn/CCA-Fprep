package com.example.projectstatus;

/**
 * The capability map in one place. Registration names must match exactly
 * ("Check the basics" #3), so annotations, startup self-check and tests all use these constants.
 */
public final class Capabilities {

    public static final String SERVER_NAME = "project-status";
    public static final String SERVER_VERSION = "1.0.0";

    /** The ONE tool: read-only, "do" (compute a snapshot), no side effects. */
    public static final String TOOL_GET_PROJECT_STATUS = "get_project_status";

    /** The ONE resource: "read" (context, not execution). Logical URI, never resolved from user input. */
    public static final String RESOURCE_README_URI = "file:///README.md";

    /** The ONE prompt: a named, versioned workflow. */
    public static final String PROMPT_SUMMARIZE_PROJECT = "summarize_project";

    private Capabilities() {
    }
}
