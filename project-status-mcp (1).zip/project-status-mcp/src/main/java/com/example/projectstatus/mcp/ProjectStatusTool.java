package com.example.projectstatus.mcp;

import org.springaicommunity.mcp.annotation.McpTool;
import org.springframework.stereotype.Component;

import com.example.projectstatus.Capabilities;
import com.example.projectstatus.model.ProjectStatus;
import com.example.projectstatus.service.ProjectStatusService;

/**
 * Tool = DO. Here "do" means compute a snapshot: read-only, no arguments, no side effects.
 * It cannot run commands, touch a database, send email or call the network.
 */
@Component
public class ProjectStatusTool {

    private final ProjectStatusService service;

    public ProjectStatusTool(ProjectStatusService service) {
        this.service = service;
    }

    @McpTool(
            name = Capabilities.TOOL_GET_PROJECT_STATUS,
            description = """
                    Return a read-only snapshot of the project's current status: health, task counts, \
                    key metrics, blockers and the recommended next step. Use when the user asks how the \
                    project is doing or what to work on next. Takes no arguments. It changes nothing \
                    and cannot run commands.""")
    public ProjectStatus getProjectStatus() {
        return service.currentStatus();
    }
}
