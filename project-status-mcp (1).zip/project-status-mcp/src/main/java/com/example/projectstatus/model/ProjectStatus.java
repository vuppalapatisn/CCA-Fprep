package com.example.projectstatus.model;

import java.util.List;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

/**
 * Structured results: one stable, versioned schema on every call, snake_case field names
 * (next_step, uptime_percent, ...). Fields cover the "useful first tool" snapshot:
 * health (status), tasks, metrics, blockers, next step.
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public record ProjectStatus(
        int version,
        String project,
        String status,
        String summary,
        Tasks tasks,
        Metrics metrics,
        List<Blocker> blockers,
        String nextStep,
        String timestamp) {

    @JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
    public record Tasks(int total, int done, int inProgress, int notStarted) {
    }

    @JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
    public record Metrics(double uptimePercent, int activeUsers) {
    }

    @JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
    public record Blocker(String title, String owner, String eta) {
    }
}
