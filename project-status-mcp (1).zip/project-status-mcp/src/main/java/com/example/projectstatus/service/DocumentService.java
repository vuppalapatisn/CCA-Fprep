package com.example.projectstatus.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

/**
 * Read-only access to the two bundled documents. File names are fixed constants:
 * no caller-supplied path ever reaches the file system.
 */
@Service
public class DocumentService {

    private static final String README_FILE = "project-readme.md";
    private static final String CHANGELOG_FILE = "project-changelog.md";

    public String readme() {
        return read(README_FILE);
    }

    public String changelog() {
        return read(CHANGELOG_FILE);
    }

    private String read(String file) {
        try (InputStream in = new ClassPathResource(file).getInputStream()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Could not read " + file, e);
        }
    }
}
