# Acme Dashboard

Acme Dashboard is a metrics and alerting platform for tracking Acme's platform health.

## Overview
- Shows uptime and active users in near real time
- Lists open blockers with owners and ETAs
- Tracks task progress for the current milestone

## Setup
1. Install Java 21 and Node.js 20
2. Copy `.env.example` to `.env` and fill in the API keys
3. Run `make dev`

## Usage
- Open the dashboard at http://localhost:3000
- Use the status tool or the summarize_project prompt for a quick overview
