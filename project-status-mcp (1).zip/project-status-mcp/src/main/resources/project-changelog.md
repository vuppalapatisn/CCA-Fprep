# Changelog

## Unreleased
- Added alerts
- Improved reporting
- Fixed auth bug
