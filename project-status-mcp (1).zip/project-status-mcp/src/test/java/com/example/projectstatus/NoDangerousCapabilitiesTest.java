package com.example.projectstatus;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;

/**
 * Block arbitrary shell / clear boundaries / read-only by default.
 * Fails the build if main code starts using shell, database, mail, network or file-writing APIs.
 * It also bans System.out: with stdio, stdout carries the protocol and stray output corrupts it.
 */
class NoDangerousCapabilitiesTest {

    private static final List<String> FORBIDDEN = List.of(
            // run shell / external commands
            "ProcessBuilder", "Runtime.getRuntime",
            // direct database access
            "java.sql", "JdbcTemplate",
            // send email
            "jakarta.mail", "javax.mail", "JavaMailSender",
            // outbound HTTP / scraping
            "java.net.http", "RestClient", "RestTemplate", "WebClient",
            // writing to or deleting from the file system (read-only server)
            "Files.write", "Files.delete", "Files.copy", "Files.move", "Files.createFile",
            "Files.createDirectories", "FileOutputStream", "FileWriter",
            // would corrupt the stdio protocol stream
            "System.out");

    @Test
    void mainSourcesContainNoDangerousApis() throws IOException {
        Path root = Path.of("src/main/java");
        try (Stream<Path> files = Files.walk(root)) {
            for (Path file : files.filter(p -> p.toString().endsWith(".java")).toList()) {
                String source = Files.readString(file);
                for (String token : FORBIDDEN) {
                    assertThat(source)
                            .as("%s must not use %s", file, token)
                            .doesNotContain(token);
                }
            }
        }
    }
}
