package com.example.projectstatus;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.junit.jupiter.api.Test;

/** Server identity and "stdio first" settings must not drift from the constants. */
class ServerIdentityTest {

    private Properties load() throws IOException {
        Properties p = new Properties();
        try (InputStream in = getClass().getResourceAsStream("/application.properties")) {
            assertThat(in).as("application.properties").isNotNull();
            p.load(in);
        }
        return p;
    }

    @Test
    void nameAndVersionMatchConstants() throws IOException {
        Properties p = load();
        assertThat(p.getProperty("spring.ai.mcp.server.name")).isEqualTo(Capabilities.SERVER_NAME);
        assertThat(p.getProperty("spring.ai.mcp.server.version")).isEqualTo(Capabilities.SERVER_VERSION);
    }

    @Test
    void stdioFirstSettings() throws IOException {
        Properties p = load();
        assertThat(p.getProperty("spring.ai.mcp.server.stdio")).isEqualTo("true");
        assertThat(p.getProperty("spring.main.web-application-type")).isEqualTo("none");
        assertThat(p.getProperty("spring.main.banner-mode")).isEqualTo("off");
    }
}
