package com.example.projectstatus;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.example.projectstatus.model.ProjectStatus;
import com.example.projectstatus.service.ProjectStatusService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

class ProjectStatusServiceTest {

    private final Clock clock = Clock.fixed(Instant.parse("2026-10-25T10:21:03Z"), ZoneOffset.UTC);
    private final ProjectStatusService service = new ProjectStatusService(clock);

    @Test
    void returnsUsefulSnapshot() {
        ProjectStatus s = service.currentStatus();

        assertThat(s.version()).isEqualTo(1);
        assertThat(s.project()).isEqualTo("acme-dashboard");
        assertThat(s.status()).isEqualTo("healthy");
        assertThat(s.tasks().total()).isEqualTo(12);
        assertThat(s.tasks().done()).isEqualTo(7);
        assertThat(s.tasks().inProgress()).isEqualTo(3);
        assertThat(s.tasks().notStarted()).isEqualTo(2);
        assertThat(s.metrics().uptimePercent()).isEqualTo(99.95);
        assertThat(s.metrics().activeUsers()).isEqualTo(1234);
        assertThat(s.blockers()).hasSize(2);
        assertThat(s.blockers().get(0).title()).isEqualTo("API rate limit risk");
        assertThat(s.nextStep()).isNotBlank();
        assertThat(s.timestamp()).isEqualTo("2026-10-25T10:21:03Z");
    }

    @Test
    void serializesToStableSnakeCaseSchema() throws Exception {
        JsonNode json = new ObjectMapper().readTree(service.currentStatusJson());

        for (String field : new String[] {
                "version", "project", "status", "summary", "tasks", "metrics",
                "blockers", "next_step", "timestamp" }) {
            assertThat(json.has(field)).as("top-level field %s", field).isTrue();
        }
        assertThat(json.get("tasks").has("in_progress")).isTrue();
        assertThat(json.get("tasks").has("not_started")).isTrue();
        assertThat(json.get("metrics").has("uptime_percent")).isTrue();
        assertThat(json.get("metrics").has("active_users")).isTrue();
        assertThat(json.get("blockers").get(0).has("title")).isTrue();
        assertThat(json.get("blockers").get(0).has("owner")).isTrue();
        assertThat(json.get("blockers").get(0).has("eta")).isTrue();
    }

    @Test
    void shapeCheckPassesForRealDataAndFailsForBrokenData() {
        assertThat(ProjectStatusService.problems(service.currentStatus())).isEmpty();

        ProjectStatus broken = new ProjectStatus(0, "", null, null, null, null, null, null, null);
        List<String> problems = ProjectStatusService.problems(broken);
        assertThat(problems).contains("tasks is missing", "next_step is missing", "version must be 1");
    }
}
