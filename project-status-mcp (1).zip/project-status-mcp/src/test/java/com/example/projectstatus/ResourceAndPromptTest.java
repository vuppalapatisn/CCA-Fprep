package com.example.projectstatus;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

import org.junit.jupiter.api.Test;

import com.example.projectstatus.mcp.ReadmeResource;
import com.example.projectstatus.mcp.SummarizeProjectPrompt;
import com.example.projectstatus.service.DocumentService;
import com.example.projectstatus.service.ProjectStatusService;

import io.modelcontextprotocol.spec.McpSchema.GetPromptResult;
import io.modelcontextprotocol.spec.McpSchema.ReadResourceResult;
import io.modelcontextprotocol.spec.McpSchema.TextContent;
import io.modelcontextprotocol.spec.McpSchema.TextResourceContents;

class ResourceAndPromptTest {

    private final Clock clock = Clock.fixed(Instant.parse("2026-10-25T10:21:03Z"), ZoneOffset.UTC);
    private final DocumentService documents = new DocumentService();
    private final ProjectStatusService status = new ProjectStatusService(clock);
    private final SummarizeProjectPrompt prompt = new SummarizeProjectPrompt(documents, status);

    private static String text(GetPromptResult result) {
        assertThat(result.messages()).hasSize(1);
        return ((TextContent) result.messages().get(0).content()).text();
    }

    // ---- Resource: readable by URI -------------------------------------------------

    @Test
    void readmeIsReadableByItsUri() {
        ReadResourceResult result = new ReadmeResource(documents).readme();

        assertThat(result.contents()).hasSize(1);
        TextResourceContents contents = (TextResourceContents) result.contents().get(0);
        assertThat(contents.uri()).isEqualTo("file:///README.md");
        assertThat(contents.mimeType()).isEqualTo("text/markdown");
        assertThat(contents.text()).startsWith("# Acme Dashboard");
    }

    // ---- Prompt: template + inputs -------------------------------------------------

    @Test
    void defaultIsLatestTemplateWithServerSuppliedInputs() {
        String t = text(prompt.summarizeProject(null, null, null));

        assertThat(t).contains("Health", "Key Metrics", "Risks", "Next Best Action");
        assertThat(t).contains("# Acme Dashboard");     // {readme} input
        assertThat(t).contains("acme-dashboard");       // {status} input
        assertThat(t).doesNotContain("{readme}").doesNotContain("{status}");
    }

    @Test
    void callerSuppliedInputsAreUsed() {
        String t = text(prompt.summarizeProject("# Other Service\nHello", "{\"health\":\"degraded\"}", "2"));

        assertThat(t).contains("# Other Service").contains("degraded");
        assertThat(t).doesNotContain("acme-dashboard");
    }

    @Test
    void registeredResourceUriIsAccepted() {
        String t = text(prompt.summarizeProject("file:///README.md", null, null));
        assertThat(t).contains("# Acme Dashboard");
    }

    @Test
    void version1ExposesTheWorkflow() {
        String t = text(prompt.summarizeProject(null, null, "1"));

        assertThat(t).contains("CHANGELOG", "Project Overview", "Recent Changes", "Risks / Blockers", "Next Steps");
        assertThat(t).contains("Fixed auth bug");
    }

    @Test
    void descriptionCarriesTheVersion() {
        assertThat(prompt.summarizeProject(null, null, null).description()).endsWith("v2");
        assertThat(prompt.summarizeProject(null, null, "1").description()).endsWith("v1");
    }

    // ---- Governance / safety -------------------------------------------------------

    @Test
    void unknownVersionIsRejected() {
        assertThatThrownBy(() -> prompt.summarizeProject(null, null, "7"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void unregisteredUrisAreNotAvailable() {
        for (String uri : new String[] { "file:///etc/passwd", "file:///svc/README.md", "https://example.com/x" }) {
            assertThatThrownBy(() -> prompt.summarizeProject(uri, null, null))
                    .as(uri)
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("registered");
        }
    }

    @Test
    void invalidStatusJsonIsRejected() {
        assertThatThrownBy(() -> prompt.summarizeProject(null, "not json", null))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> prompt.summarizeProject(null, "[1,2]", null))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void oversizedInputsAreRejected() {
        String big = "x".repeat(20_001);
        assertThatThrownBy(() -> prompt.summarizeProject(big, null, null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("too large");
    }
}
