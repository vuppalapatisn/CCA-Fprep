package com.example.projectstatus;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.Map;

import org.junit.jupiter.api.Test;

import com.example.projectstatus.mcp.PromptTemplates;

/** Template stays stable; only the inputs change. */
class PromptTemplatesTest {

    @Test
    void rendersPlaceholders() {
        assertThat(PromptTemplates.render("A {x} B {y}", Map.of("x", "1", "y", "2"))).isEqualTo("A 1 B 2");
    }

    @Test
    void insertedValuesAreNotRescanned() {
        assertThat(PromptTemplates.render("A {x}", Map.of("x", "{y}"))).isEqualTo("A {y}");
    }

    @Test
    void missingInputFails() {
        assertThatThrownBy(() -> PromptTemplates.render("{x}", Map.of()))
                .isInstanceOf(IllegalStateException.class);
    }

    @Test
    void everySupportedVersionRendersCompletely() {
        for (String version : PromptTemplates.SUPPORTED) {
            String text = PromptTemplates.render(PromptTemplates.template(version),
                    Map.of("readme", "R", "status", "S", "changelog", "C"));
            assertThat(text).as("version %s", version).doesNotContain("{");
        }
    }

    @Test
    void latestIsSupported() {
        assertThat(PromptTemplates.SUPPORTED).contains(PromptTemplates.LATEST);
    }

    @Test
    void unknownVersionIsRejected() {
        assertThatThrownBy(() -> PromptTemplates.template("99"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Supported");
    }
}
