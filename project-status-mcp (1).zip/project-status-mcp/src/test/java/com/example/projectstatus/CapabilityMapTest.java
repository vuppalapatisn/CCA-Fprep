package com.example.projectstatus;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.example.projectstatus.mcp.CapabilityCatalog;

/**
 * Small capability map / one responsibility: exactly 1 tool, 1 resource, 1 prompt.
 * Unregistered = not available. A fourth capability fails this test on purpose,
 * so every addition is a deliberate, reviewed decision.
 */
class CapabilityMapTest {

    @Test
    void exactlyOneToolOneResourceOnePrompt() {
        var registered = CapabilityCatalog.scan();

        assertThat(registered.tools()).containsExactly(Capabilities.TOOL_GET_PROJECT_STATUS);
        assertThat(registered.resources()).containsExactly(Capabilities.RESOURCE_README_URI);
        assertThat(registered.prompts()).containsExactly(Capabilities.PROMPT_SUMMARIZE_PROJECT);
    }
}
