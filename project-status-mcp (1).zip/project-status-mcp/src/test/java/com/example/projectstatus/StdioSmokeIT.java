package com.example.projectstatus;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * "Test discovery before execution": launches the real jar as a subprocess (exactly what a host does)
 * and speaks raw JSON-RPC over stdin/stdout in this order:
 *
 *   initialize -> list tools -> list resources -> read README -> call get_project_status
 *   -> list prompts -> get summarize_project
 *
 * Runs in `mvn verify` (failsafe) after the jar is built. Skipped if the jar does not exist.
 * Also asserts that stdout contains ONLY JSON-RPC (no stray output).
 */
class StdioSmokeIT {

    private static final ObjectMapper JSON = new ObjectMapper();
    private static final long TIMEOUT_SECONDS = 30;

    private Process process;
    private BufferedWriter stdin;
    private final BlockingQueue<JsonNode> inbox = new LinkedBlockingQueue<>();
    private final List<String> strayStdout = new CopyOnWriteArrayList<>();
    private int nextId = 1;

    @BeforeEach
    void startServer() throws Exception {
        Path jar = Path.of(System.getProperty("mcp.jar", "target/project-status-mcp-1.0.0.jar"));
        assumeTrue(Files.exists(jar), "Jar not found, run `mvn package` first: " + jar);

        String java = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        process = new ProcessBuilder(java, "-jar", jar.toString())
                .redirectError(ProcessBuilder.Redirect.INHERIT) // stderr = logs, visible in test output
                .start();
        stdin = new BufferedWriter(new OutputStreamWriter(process.getOutputStream(), UTF_8));

        Thread reader = new Thread(() -> {
            try (var r = new BufferedReader(new InputStreamReader(process.getInputStream(), UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    if (line.isBlank()) continue;
                    try {
                        inbox.add(JSON.readTree(line));
                    } catch (IOException notJson) {
                        strayStdout.add(line);
                    }
                }
            } catch (IOException processEnded) {
                // expected at shutdown
            }
        }, "stdout-reader");
        reader.setDaemon(true);
        reader.start();
    }

    @AfterEach
    void stopServer() throws Exception {
        if (process != null) {
            process.destroy();
            if (!process.waitFor(5, TimeUnit.SECONDS)) {
                process.destroyForcibly();
            }
        }
    }

    @Test
    void listThenCall() throws Exception {
        // 0. initialize (handshake)
        JsonNode init = result("initialize", Map.of(
                "protocolVersion", "2025-06-18",
                "capabilities", Map.of(),
                "clientInfo", Map.of("name", "smoke-test", "version", "1.0")));
        assertThat(init.path("serverInfo").path("name").asText()).isEqualTo(Capabilities.SERVER_NAME);
        assertThat(init.path("serverInfo").path("version").asText()).isEqualTo(Capabilities.SERVER_VERSION);
        notifyServer("notifications/initialized");

        // 1. list tools
        JsonNode tools = result("tools/list", null).path("tools");
        assertThat(names(tools, "name")).containsExactly(Capabilities.TOOL_GET_PROJECT_STATUS);

        // 2. list resources
        JsonNode resources = result("resources/list", null).path("resources");
        assertThat(names(resources, "uri")).containsExactly(Capabilities.RESOURCE_README_URI);
        assertThat(resources.get(0).path("mimeType").asText()).isEqualTo("text/markdown");

        // 3. read README
        JsonNode read = result("resources/read", Map.of("uri", Capabilities.RESOURCE_README_URI));
        assertThat(read.path("contents").get(0).path("text").asText()).startsWith("# Acme Dashboard");

        // 4. call get_project_status -> structured JSON
        JsonNode call = result("tools/call", Map.of(
                "name", Capabilities.TOOL_GET_PROJECT_STATUS, "arguments", Map.of()));
        assertThat(call.path("isError").asBoolean(false)).isFalse();
        JsonNode status = call.has("structuredContent")
                ? call.get("structuredContent")
                : JSON.readTree(call.path("content").get(0).path("text").asText());
        for (String field : List.of("version", "project", "status", "tasks", "metrics",
                "blockers", "next_step", "timestamp")) {
            assertThat(status.has(field)).as("field %s", field).isTrue();
        }

        // 5. list prompts, then load summarize_project with known inputs
        JsonNode prompts = result("prompts/list", null).path("prompts");
        assertThat(names(prompts, "name")).containsExactly(Capabilities.PROMPT_SUMMARIZE_PROJECT);

        JsonNode prompt = result("prompts/get", Map.of(
                "name", Capabilities.PROMPT_SUMMARIZE_PROJECT, "arguments", Map.of()));
        String promptText = prompt.path("messages").get(0).path("content").path("text").asText();
        assertThat(promptText).contains("Key Metrics", "Next Best Action", "# Acme Dashboard");

        // 6. unregistered resource URI is not available (error, not content)
        JsonNode rejected = call("prompts/get", Map.of(
                "name", Capabilities.PROMPT_SUMMARIZE_PROJECT,
                "arguments", Map.of("readme", "file:///etc/passwd")));
        assertThat(rejected.has("error")).as("unregistered URI must be rejected").isTrue();

        // stdout must carry only JSON-RPC
        assertThat(strayStdout).as("stray non-JSON output on stdout").isEmpty();
    }

    // ----------------------------------------------------------------- helpers

    private static List<String> names(JsonNode array, String field) {
        List<String> out = new ArrayList<>();
        array.forEach(n -> out.add(n.path(field).asText()));
        return out;
    }

    private void send(ObjectNode message) throws IOException {
        stdin.write(JSON.writeValueAsString(message));
        stdin.write("\n");
        stdin.flush();
    }

    private void notifyServer(String method) throws IOException {
        ObjectNode msg = JSON.createObjectNode();
        msg.put("jsonrpc", "2.0");
        msg.put("method", method);
        send(msg);
    }

    private JsonNode call(String method, Object params) throws Exception {
        int id = nextId++;
        ObjectNode msg = JSON.createObjectNode();
        msg.put("jsonrpc", "2.0");
        msg.put("id", id);
        msg.put("method", method);
        if (params != null) {
            msg.set("params", JSON.valueToTree(params));
        }
        send(msg);

        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(TIMEOUT_SECONDS);
        while (System.nanoTime() < deadline) {
            JsonNode n = inbox.poll(200, TimeUnit.MILLISECONDS);
            if (n != null && !n.has("method") && n.path("id").asInt(-1) == id) {
                return n;
            }
        }
        throw new AssertionError("Timed out waiting for the response to " + method);
    }

    private JsonNode result(String method, Object params) throws Exception {
        JsonNode response = call(method, params);
        assertThat(response.has("error")).as("%s returned error: %s", method, response.path("error")).isFalse();
        return response.get("result");
    }
}
