package com.example.projectstatus.startup;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.Clock;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.example.projectstatus.Capabilities;
import com.example.projectstatus.mcp.CapabilityCatalog;
import com.example.projectstatus.mcp.CapabilityCatalog.Registered;
import com.example.projectstatus.service.DocumentService;
import com.example.projectstatus.service.ProjectStatusService;

/** "Debug the basics first": registration names, README and JSON shape are verified at startup. */
class StartupSelfCheckTest {

    private final StartupSelfCheck check =
            new StartupSelfCheck(new ProjectStatusService(Clock.systemUTC()), new DocumentService());

    @Test
    void passesForTheRealCapabilityMap() {
        assertThatCode(() -> check.verify(CapabilityCatalog.scan())).doesNotThrowAnyException();
    }

    @Test
    void failsFastOnUnexpectedTool() {
        Registered withExtraTool = new Registered(
                List.of(Capabilities.TOOL_GET_PROJECT_STATUS, "run_shell"),
                List.of(Capabilities.RESOURCE_README_URI),
                List.of(Capabilities.PROMPT_SUMMARIZE_PROJECT));

        assertThatThrownBy(() -> check.verify(withExtraTool))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("run_shell");
    }

    @Test
    void failsFastOnMisspelledName() {
        Registered typo = new Registered(
                List.of("get_project_stauts"),
                List.of(Capabilities.RESOURCE_README_URI),
                List.of(Capabilities.PROMPT_SUMMARIZE_PROJECT));

        assertThatThrownBy(() -> check.verify(typo))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("get_project_stauts");
    }
}
