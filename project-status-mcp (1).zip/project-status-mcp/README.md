# project-status-mcp

A minimal, read-only MCP server built with Spring Boot and Spring AI, running over **stdio**.

**One server. One responsibility. One safe tool. One resource. One prompt.**

| Capability | Name / URI | Role |
|---|---|---|
| Tool (do) | `get_project_status` | Read-only snapshot: health, tasks, metrics, blockers, next step. No arguments |
| Resource (read) | `file:///README.md` | Project overview, setup and usage. `text/markdown`, read-only |
| Prompt (workflow) | `summarize_project` | Named, versioned workflow. Inputs: `readme`, `status`, `version` |

Server name `project-status`, version `1.0.0`.

## Requirements
Java 21, Maven 3.9+, Node.js (only for the MCP Inspector).
Pinned in `pom.xml`: Spring Boot 3.5.6, Spring AI 1.1.0 (`spring-ai.version`).
When you move to a newer Spring AI line, bump Boot and Spring AI together and re-check the annotation package
(`org.springaicommunity.mcp.annotation.*`) and the `McpSchema` imports.

> **Not yet built or run.** This project was generated without access to Maven Central, so the first
> `mvn clean verify` is the real compile check. Only the template engine (`PromptTemplates`) was compiled and
> exercised on its own.

## Quick start
```bash
mvn clean verify           # unit tests, build the jar, then the stdio smoke test (StdioSmokeIT)
java -jar target/project-status-mcp-1.0.0.jar     # waits for JSON-RPC on stdin; looks idle, that is normal
./scripts/inspect.sh       # MCP Inspector for manual testing
```

## How every slide maps to the code

### Batch 1: minimal, safe, small
| Slide | Idea | Where |
|---|---|---|
| Minimal Server | One tool, one resource, one prompt | `mcp/ProjectStatusTool`, `mcp/ReadmeResource`, `mcp/SummarizeProjectPrompt` |
| Don't build a monster / Start small | More power = more risk | `NoDangerousCapabilitiesTest` (no shell, DB, mail, network, file writes) |

### Batch 2: capability map, stdio, tool, structure, no shell
| Slide | Idea | Where |
|---|---|---|
| Small Capability Map | Register only what you need. Unregistered = not available | `CapabilityMapTest`, `Capabilities` constants, `StartupSelfCheck` |
| Stdio First | Host launches the subprocess; JSON-RPC over stdin/stdout | `application.properties`, `logback-spring.xml` |
| Useful First Tool | Skip hello world | `ProjectStatusService` + `project-status.json` |
| Structured Results | Stable, versioned schema | `model/ProjectStatus` (snake_case, `version`), `ProjectStatusServiceTest` |
| Block Arbitrary Shell | Never proxy arbitrary commands | `NoDangerousCapabilitiesTest` |

### Batch 3: resources, prompts, host, testing, debugging, scope, next steps
| Slide | Idea | Where |
|---|---|---|
| Readable By URI | Clear URI, type, description, read-only | `ReadmeResource`: `file:///README.md`, `text/markdown`. MCP has no standard `tags` field, so the tags (docs, onboarding, public) are in the description |
| Read Versus Do | Tools do, resources read | Tool = compute a snapshot. Resource = context only. Neither can change anything |
| Expose The Workflow | Prompts are workflows you can call, inspect and reuse | `SummarizeProjectPrompt`, template **v1** (README, then CHANGELOG, then risks, then summary) |
| Template Plus Inputs | Stable template, changing inputs | `PromptTemplates` (template) vs prompt arguments (inputs), template **v2** (default) |
| Governed Reuse | Named, versioned, reviewed; old versions remain | `version` argument, `PromptTemplates.SUPPORTED`, see `docs/PROMPT-GOVERNANCE.md` |
| Connect The Host | Host starts the server from a run command | `host-config/mcp.json`, `host-config/vscode-mcp.json` |
| List Then Call | Discovery before execution | `StdioSmokeIT` (initialize, list tools, list resources, read README, call tool, load prompt) |
| Check The Basics | Command path, startup errors, names, JSON shape; watch stderr | `StartupSelfCheck` (fails fast), stderr logging, `docs/TROUBLESHOOTING.md` |
| Too Much Too Soon | Complex first servers fail fast | Guard tests + one-by-one expansion rules below |
| One Responsibility | Senior engineering checklist | See the checklist below |
| Real API Next | Kubernetes API server is the next lesson | `docs/NEXT-STEPS-KUBERNETES.md` (a plan, not code, on purpose) |

## The prompt: one name, two versions
`summarize_project` takes three optional arguments:

| Argument | Meaning | Default |
|---|---|---|
| `readme` | README text, or the URI of a **registered** resource | `file:///README.md` |
| `status` | Project status JSON | The server's own `get_project_status` snapshot |
| `version` | `1` or `2` | `2` (latest) |

- **v2** (default, "template plus inputs"): README + status JSON, output sections Health, Key Metrics, Risks, Next Best Action.
- **v1** ("expose the workflow"): README + CHANGELOG, output sections Project Overview, Recent Changes, Risks / Blockers, Next Steps.

Safety rules enforced in code:
- Any other URI (`file:///etc/passwd`, `https://...`) is rejected. Unregistered = not available.
- Inputs are capped at 20,000 characters, and `status` must be a JSON object.
- Inputs are wrapped in `<readme>` / `<status>` / `<changelog>` tags and the template says they are data, never instructions.
- Inserted values are never re-scanned for placeholders.

The CHANGELOG is bundled with the server and used only by v1. It is deliberately **not** a second resource, to keep the capability map at exactly three.
If you want clients to read it by URI, add it as a resource and update `CapabilityMapTest` on purpose.

## Connect a host
Copy a file from `host-config/` and replace the absolute paths.
- `mcp.json`: the `mcpServers` format used by Claude Desktop, Cursor and Claude Code project files (`.mcp.json`).
- `vscode-mcp.json`: VS Code format (`servers`, `type: stdio`, `${workspaceFolder}`).

Check your host's documentation for supported fields (for example `cwd` and `env`).
Use an absolute path to the jar, so the working directory does not matter.
`LOGGING_FILE_NAME` sets the log file (default: the system temp directory).

## Stdio rules
- stdout is the protocol channel. Never use `System.out` or print stack traces. A test enforces this.
- Logs go to **stderr** and to a file (`logback-spring.xml`). Hosts show stderr.
- Startup logs the server name, version, Java version and capability map, then runs a self-check.
  Any problem stops the server with a non-zero exit code.

## Testing
| Test | What it proves |
|---|---|
| `CapabilityMapTest` | Exactly 1 tool, 1 resource, 1 prompt, with the expected names |
| `NoDangerousCapabilitiesTest` | No shell, DB, mail, network, file-writing APIs or `System.out` |
| `ServerIdentityTest` | Name, version and stdio settings match the constants |
| `ProjectStatusServiceTest` | Useful data, snake_case schema, shape check |
| `PromptTemplatesTest` | Template/inputs separation, versions |
| `ResourceAndPromptTest` | Resource by URI, prompt versions, rejected URIs, bad JSON, size cap |
| `StartupSelfCheckTest` | Misspelled or extra registrations fail fast |
| `StdioSmokeIT` | The real jar, driven like a host: list, then call, stdout is clean |

Manual checklist in the Inspector:
- [ ] Server starts and connects
- [ ] Tools: only `get_project_status`, and it returns the structured JSON
- [ ] Resources: only `file:///README.md`, and it reads
- [ ] Prompts: only `summarize_project`, and it returns one user message
- [ ] stderr / log file show the startup self-check and no errors

## Senior engineering checklist
- [x] 1 server: one MCP server per responsibility
- [x] 1 responsibility: project status and context for one user problem
- [x] 1 safe tool: read or compute, no side effects
- [x] 1 resource: context, not control
- [x] 1 prompt: a repeatable, versioned workflow
- [x] Clear logs: startup, self-check and errors on stderr
- [x] Clear boundaries: no shell, least privilege, read-only by default

**Scope is a safety feature.** You can always add more. You cannot always take it back.

## Adding a capability later (one by one)
1. Write down why it is needed and the worst thing it could do if misused.
2. Prefer read-only. Writes need approval, idempotency keys and audit logging.
3. Keep tools narrow and typed. Never accept raw shell, raw SQL or arbitrary URLs.
4. Prefer a **new server** for a new responsibility (see the Kubernetes plan).
5. Update the constants, the guard tests and the startup self-check deliberately.

## Going remote later (not included on purpose)
Switch to `spring-ai-starter-mcp-server-webmvc` with `spring.ai.mcp.server.protocol=STREAMABLE`, add Spring Security
as an OAuth2 resource server with bearer tokens, and keep the same capabilities and guard tests.

## Layout
```
src/main/java/com/example/projectstatus/
  Capabilities.java                 names, URI, version (single source of truth)
  ProjectStatusMcpApplication.java  fail-fast main
  model/ProjectStatus.java          structured result (record)
  service/ProjectStatusService.java status snapshot + shape check
  service/DocumentService.java      bundled README and CHANGELOG (fixed files)
  mcp/ProjectStatusTool.java        the tool
  mcp/ReadmeResource.java           the resource
  mcp/SummarizeProjectPrompt.java   the prompt (inputs, validation)
  mcp/PromptTemplates.java          the versioned templates
  mcp/CapabilityCatalog.java        discovers what is registered
  startup/StartupSelfCheck.java     startup logs + fail-fast checks
src/main/resources/                 application.properties, logback-spring.xml, data files
host-config/                        host configuration examples
docs/                               troubleshooting, prompt governance, Kubernetes plan
```
