#!/usr/bin/env bash
# Build, then open the MCP Inspector against the stdio server (needs Node.js).
set -euo pipefail
cd "$(dirname "$0")/.."
mvn -q -DskipTests package
npx @modelcontextprotocol/inspector java -jar target/project-status-mcp-1.0.0.jar
