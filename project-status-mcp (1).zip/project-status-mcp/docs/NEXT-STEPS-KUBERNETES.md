# Next: connect a real API (Kubernetes API server)

The recap slide says it: **small wins build real confidence.**

1. Understand: you know the building blocks (tool, resource, prompt).
2. Build: you have a minimal, safe, working server.
3. Prove: you tested discovery, calls and workflows.
4. Extend: you are ready for a real API.

## Plan for the next lesson
Build a **separate** server, `k8s-mcp`, instead of growing this one ("one MCP server per responsibility"). Do not merge it into `project-status-mcp`.

| Step | What | Safety notes |
|---|---|---|
| 1 | Connect to the real Kubernetes API (for example with the fabric8 client or the official Java client) | Use a dedicated ServiceAccount or kubeconfig context. Never the cluster-admin credentials |
| 2 | Tool `list_namespaces` | Read-only |
| 3 | Tool `get_resource(kind, namespace, name)` from an **allow-list** of kinds | No `kubectl exec`, no arbitrary kind strings. Redact Secrets. Cap output size |
| 4 | Resource: a deployment manifest by URI (for example `k8s://namespaces/{namespace}/deployments/{name}`) | Context only. Redacted |
| 5 | Handle auth and errors | Structured errors (stable code, message, context, suggested action). Separate "forbidden" from "not found" from "unavailable". Timeouts and a circuit breaker |
| 6 | Build one useful tool (for example `get_pod_logs` with a line cap, or `diagnose_deployment`) | Narrow, typed, read-only |
| 7 | Prompt: `incident-analysis` | Versioned, with the same governance rules |

## Guardrails to carry over
- Read-only RBAC first (`get`, `list`, `watch` on a small set of resources). Add write verbs only with approvals.
- Keep the same guard tests (no shell, no arbitrary HTTP) and the startup self-check.
- Treat log lines and resource contents as untrusted data (prompt-injection path).
- Start with stdio, then move to a remote transport with OAuth2 only when needed.
