# Prompt governance: reuse creates governance

`summarize_project` is a **named prompt defined by the team**. Many people reuse it with different inputs
and get the same structure every time. Because everyone depends on it, it needs rules.

## Rules
1. **Named prompts are versioned.** Every released template lives in `PromptTemplates` under a version number.
2. **Changes are reviewed.** Treat prompt changes like API changes (pull request, reviewer, tests).
3. **Old versions remain** so existing users and automations stay stable. Callers can pin one with the `version` argument.
4. **Trust comes from consistency, review and clear ownership.** Name an owner for each prompt.

## How to change the prompt
1. Do not edit a released template. Add a new constant (for example `V3_TEMPLATE`) and a `case "3"` in `template()`.
2. Add `"3"` to `SUPPORTED`. Change `LATEST` only when you want it to become the default.
3. Add or update tests in `PromptTemplatesTest` and `ResourceAndPromptTest` (sections present, inputs rendered, old versions unchanged).
4. Describe the change and the reason in the pull request. Require review from the prompt owner.
5. Announce the new version and the date the previous default changed.

## Suggested review checklist
- [ ] Name is clear and the description says what it does
- [ ] Small and focused (one workflow)
- [ ] Inputs and outputs are documented (arguments and output sections)
- [ ] Inputs are treated as data, not instructions
- [ ] Output sections are stable (consumers may depend on them)
- [ ] Older versions still render and their tests pass

## Optional: enforce review with CODEOWNERS
```
# .github/CODEOWNERS   (replace the team handle)
/src/main/java/com/example/projectstatus/mcp/PromptTemplates.java   @your-org/prompt-owners
/src/main/java/com/example/projectstatus/mcp/SummarizeProjectPrompt.java   @your-org/prompt-owners
```
