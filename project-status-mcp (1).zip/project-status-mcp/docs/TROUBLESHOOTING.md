# Troubleshooting: check the basics first

Most issues are in the basics, not the protocol. Work through the checks in order, then debug the logic.
**Start here. Don't guess. Verify.** Watch **stderr** (and the log file): it is your best friend.

| # | Check | Questions | How to verify |
|---|---|---|---|
| 1 | **Command path** | Can the host find and run the command? Does the file exist? | Run the exact command from the host config in a terminal: `java -jar /abs/path/project-status-mcp-1.0.0.jar`. Use an absolute path. Check `java -version` (needs 21) |
| 2 | **Startup errors** | Does the server start cleanly? (the Java equivalent of an import error) | Read stderr for `Startup failed`, `ClassNotFoundException`, `UnsupportedClassVersionError` (wrong Java), or a Spring context error. Rebuild with `mvn clean package` |
| 3 | **Registration names** | Do the tool, resource and prompt register with the right names? | Look for `Self-check failed: Registered tools [...] but expected [...]` in stderr. Names come from `Capabilities.java`. In the Inspector, list tools, resources and prompts |
| 4 | **JSON shape** | Is the response valid JSON with the expected fields and types? | `Self-check failed: next_step is missing`, or run `ProjectStatusServiceTest`. Call the tool in the Inspector and compare with the schema |

Then: **now debug the logic.**

## Typical symptoms
| Symptom | Likely cause |
|---|---|
| Host shows "server failed to start" or hangs on connect | Check 1 or 2. Run the command by hand and read stderr |
| Host connects but the list is empty | Check 3. Annotation package or scanning problem, or the class is not a `@Component` |
| Garbled or "invalid JSON" errors in the host | Something printed to **stdout**. Remove `System.out` and console logging (`NoDangerousCapabilitiesTest` guards this) |
| Tool returns an error | Check 4. Read the log file and the status data file |
| Works in the terminal, fails in the host | Relative paths or a different working directory. Use absolute paths and set `LOGGING_FILE_NAME` |

## Where the logs are
- stderr (shown by most hosts in their MCP logs)
- File: `$LOGGING_FILE_NAME` if set, otherwise `<system temp dir>/project-status-mcp.log`

## Pro tip
Add startup logs, fail fast, be noisy, and make problems obvious. `StartupSelfCheck` already does this: it stops the server
with a clear message if anything in checks 3 or 4 is wrong.
