# Spring AI Code Health Project

Steps:
1. Configure OPENAI_API_KEY.
2. Run mvn spring-boot:run
3. POST /api/chat

Architecture:
Controller -> ConversationService -> PromptBuilder -> ResponseValidator -> AI Client.